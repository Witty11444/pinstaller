import os
import sqlite3
import ssl
import urllib.request
import zipfile
import xbmc
import xbmcgui
import xbmcvfs

# ลิงก์ไฟล์ kodibackup_Lzae24.zip ของคุณ (แปลงเป็น dl=1 เรียบร้อยแล้ว)
ZIP_URL = "https://www.dropbox.com/scl/fi/mxd2sp0n1242c55r78cf3/kodibackup_Lzae24.zip?rlkey=x73btg1x4g1jwvp6n2y4v80t1&st=tck91r5l&dl=1"

def enable_all_addons():
    try:
        db_dir = xbmcvfs.translatePath('special://database/')
        for file in os.listdir(db_dir):
            if file.startswith('Addons') and file.endswith('.db'):
                db_path = os.path.join(db_dir, file)
                conn = sqlite3.connect(db_path)
                cursor = conn.cursor()
                cursor.execute("UPDATE installed SET enabled = 1")
                conn.commit()
                conn.close()
    except Exception:
        pass

def install_build():
    dialog = xbmcgui.Dialog()

    confirm = dialog.yesno("PInstaller", "ตรวจพบแพ็กเกจติดตั้งใหม่ (kodibackup_Lzae24)\nต้องการดาวน์โหลดและติดตั้งทับข้อมูลเดิมทันทีหรือไม่?")
    if not confirm:
        return

    progress = xbmcgui.DialogProgress()
    progress.create("PInstaller กำลังติดตั้ง", "กำลังเชื่อมต่อกับ Dropbox...")

    home_path = xbmcvfs.translatePath('special://home/')
    temp_dir = xbmcvfs.translatePath('special://temp/')
    temp_zip = os.path.join(temp_dir, 'backup_build.zip')

    if os.path.exists(temp_zip):
        try:
            os.remove(temp_zip)
        except Exception:
            pass

    try:
        ssl_context = ssl._create_unverified_context()
        req = urllib.request.Request(ZIP_URL, headers={'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)'})
        
        with urllib.request.urlopen(req, context=ssl_context, timeout=60) as response, open(temp_zip, 'wb') as out_file:
            total_size = int(response.info().get('Content-Length', 0))
            downloaded = 0
            chunk_size = 1024 * 256

            while True:
                if progress.iscanceled():
                    raise Exception("ผู้ใช้ยกเลิกการดาวน์โหลด")
                chunk = response.read(chunk_size)
                if not chunk:
                    break
                out_file.write(chunk)
                downloaded += len(chunk)
                if total_size > 0:
                    percent = min(int((downloaded * 100) / total_size), 100)
                    mb_done = downloaded / (1024 * 1024)
                    mb_total = total_size / (1024 * 1024)
                    progress.update(percent, f"กำลังดาวน์โหลด: {mb_done:.1f} MB / {mb_total:.1f} MB ({percent}%)")
                else:
                    mb_done = downloaded / (1024 * 1024)
                    progress.update(50, f"กำลังดาวน์โหลด: {mb_done:.1f} MB...")

        if not zipfile.is_zipfile(temp_zip):
            raise Exception("ไฟล์ที่โหลดมาไม่ใช่ไฟล์ .zip (กรุณาเช็กลิงก์ Dropbox)")

        progress.update(0, "กำลังตรวจสอบโครงสร้างไฟล์...")
        with zipfile.ZipFile(temp_zip, 'r') as zip_ref:
            file_list = zip_ref.namelist()
            total_files = len(file_list)
            
            for idx, file in enumerate(file_list):
                if progress.iscanceled():
                    raise Exception("ผู้ใช้ยกเลิกการแตกไฟล์")
                
                clean_path = file.replace('\\', '/')
                
                if "plugin.program.pinstaller" in clean_path or clean_path.endswith('.db'):
                    continue
                    
                try:
                    zip_ref.extract(file, home_path)
                except Exception:
                    pass
                    
                if idx % 50 == 0:
                    percent = min(int((idx * 100) / total_files), 100)
                    progress.update(percent, f"กำลังติดตั้งไฟล์ ({idx}/{total_files})...")
                    xbmc.sleep(1)

        if os.path.exists(temp_zip):
            os.remove(temp_zip)

        progress.update(100, "กำลังเปิดใช้งาน Add-ons ทั้งหมด...")
        enable_all_addons()

        progress.close()
        dialog.ok("ติดตั้งเสร็จสมบูรณ์!", "ระบบติดตั้งข้อมูลเรียบร้อยแล้ว\nกดตกลงเพื่อปิด Kodi (จากนั้นกดเปิด Kodi ขึ้นมาใหม่)")
        os._exit(1)

    except Exception as e:
        if os.path.exists(temp_zip):
            try:
                os.remove(temp_zip)
            except Exception:
                pass
        progress.close()
        dialog.ok("เกิดข้อผิดพลาด", f"ไม่สามารถติดตั้งได้:\n{str(e)}")

if __name__ == '__main__':
    install_build()
