import os
import xbmc
import xbmcvfs

addon_data = xbmcvfs.translatePath('special://profile/addon_data/plugin.program.pinstaller/')
flag_file = os.path.join(addon_data, 'first_run.done')

if not os.path.exists(flag_file):
    if not os.path.exists(addon_data):
        os.makedirs(addon_data)
    with open(flag_file, 'w') as f:
        f.write('done')
    
    xbmc.sleep(2000)
    xbmc.executebuiltin('RunAddon(plugin.program.pinstaller)')
