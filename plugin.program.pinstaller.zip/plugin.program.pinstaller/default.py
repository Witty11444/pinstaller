import json
import os
import shutil
import sqlite3
import ssl
import urllib.parse
import urllib.request
import zipfile
import xbmc
import xbmcgui
import xbmcvfs

# ลิงก์เซิร์ฟเวอร์ PythonAnywhere ของคุณ
SERVER_URL = "https://witty112.pythonanywhere.com"

def get_filename_from_url(url):
    try:
        parsed = urllib.parse.urlparse(url)
        filename = os.path.basename(parsed.path)
        if filename.lower().endswith('.zip'):
            return filename[:-4]
        return filename if filename else "Custom Build"
    except Exception:
        return "Custom Build"

def clear_old_data():
    home_path = xbmcvfs.translatePath('special://home/')
    for folder in ['addons', 'userdata']:
        target_dir = os.path.join(home_path, folder)
        if not os.path.exists(target_dir):
            continue
        for item in os.listdir(target_dir):
            if item in ['plugin.program.pinstaller', 'packages', 'Database']:
                continue
            item_path = os.path.join(target_dir, item)
            try:
                if os.path.isdir(item_path):
                    shutil.rmtree(item_path)
                else:
                    os.remove(item_path)
            except Exception:
                pass

def mark_first_run_done():
    try:
        addon_data = xbmcvfs.translatePath('special://profile/addon_data/plugin.program.pinstaller/')
        if not os.path.exists(addon_data):
            os.makedirs(addon_data)
        with open(os.path.join(addon_data, 'first_run.done'), 'w') as f:
            f.write('done')
    except Exception:
        pass

def enable_all_addons():
    try:
        xbmc.executebuiltin('UpdateLocalAddons')
        xbmc.sleep(2000)
        db_dir = xbmcvfs.translatePath('special://database/')
        for file in os.listdir(db_dir):
            if file.startswith('Addons') and file.endswith('.db'):
                conn = sqlite3.connect(os.path.join(db_dir, file))
                conn.cursor().execute("UPDATE installed SET enabled = 1")
                conn.commit()
                conn.close()
    except Exception:
        pass

def install_build():
    dialog = xbmcgui.Dialog()
    code = dialog.input("PInstaller - Enter Access Code", type=xbmcgui.INPUT_ALPHANUM)
    if not code:
        mark_first_run_done()
        return

    code_clean = code.strip().lower()
    progress = xbmcgui.DialogProgress()
    progress.create("PInstaller", "Verifying code with server...")

    try:
        ssl_context = ssl._create_unverified_context()
        api_url = f"{SERVER_URL}/api/get_build?code={urllib.parse.quote(code_clean)}"
        req = urllib.request.Request(api_url, headers={'User-Agent': 'Mozilla/5.0'})
        
        with urllib.request.urlopen(req, context=ssl_context, timeout=20) as resp:
            data = json.loads(resp.read().decode('utf-8'))
            
        if data.get("status") != "ok":
            raise Exception("Invalid or expired code!")
            
        zip_url = data["url"]
        build_name = get_filename_from_url(zip_url)
        progress.close()

    except Exception:
        progress.close()
        dialog.ok("Access Denied", "Invalid code or code has already been used!")
        mark_first_run_done()
        return

    # เริ่มล้างข้อมูลเก่าและดาวน์โหลดไฟล์
    progress.create("PInstaller", f"Installing {build_name}...\nWiping old data...")
    clear_old_data()

    home_path = xbmcvfs.translatePath('special://home/')
    temp_zip = os.path.join(xbmcvfs.translatePath('special://temp/'), 'backup_build.zip')

    try:
        req = urllib.request.Request(zip_url, headers={'User-Agent': 'Mozilla/5.0'})
        with urllib.request.urlopen(req, context=ssl_context, timeout=60) as response, open(temp_zip, 'wb') as out_file:
            total_size = int(response.info().get('Content-Length', 0))
            downloaded = 0
            while True:
                if progress.iscanceled():
                    raise Exception("Download canceled")
                chunk = response.read(1024 * 256)
                if not chunk:
                    break
                out_file.write(chunk)
                downloaded += len(chunk)
                if total_size > 0:
                    percent = min(int((downloaded * 100) / total_size), 100)
                    progress.update(percent, f"Downloading: {downloaded/(1024*1024):.1f} MB / {total_size/(1024*1024):.1f} MB ({percent}%)")

        if not zipfile.is_zipfile(temp_zip):
            raise Exception("Invalid zip file")

        with zipfile.ZipFile(temp_zip, 'r') as zip_ref:
            file_list = zip_ref.namelist()
            total_files = len(file_list)
            for idx, file in enumerate(file_list):
                if progress.iscanceled():
                    raise Exception("Extraction canceled")
                clean_path = file.replace('\\', '/')
                if "plugin.program.pinstaller" in clean_path or clean_path.endswith('.db'):
                    continue
                try:
                    zip_ref.extract(file, home_path)
                except Exception:
                    pass
                if idx % 50 == 0:
                    progress.update(min(int((idx * 100) / total_files), 100), f"Extracting ({idx}/{total_files})...")
                    xbmc.sleep(1)

        if os.path.exists(temp_zip):
            os.remove(temp_zip)

        progress.update(90, "Enabling add-ons...")
        mark_first_run_done()
        enable_all_addons()

        progress.close()
        dialog.ok("Installation Complete!", f"'{build_name}' installed.\nPress OK to close Kodi.")
        os._exit(1)

    except Exception as e:
        if os.path.exists(temp_zip):
            try:
                os.remove(temp_zip)
            except Exception:
                pass
        mark_first_run_done()
        progress.close()
        dialog.ok("Installation Error", f"Failed: {str(e)}")

if __name__ == '__main__':
    install_build()
